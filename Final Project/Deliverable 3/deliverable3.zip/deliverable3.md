![JN](jimmy%20Neuron.jpeg)
# Jimmy Neutron
---
## Medical Laboratory Scientist
---
My passion is to make the world a more tension free place. Many diseases cause us distress and put us in detrimental situations. I would like to cure the world of those diseases to make the world a better place.

## Experience
---
***Retroville Hospital***, May, 2002-2006

* Volunteered for 4 years aiding nurses with medication and help doctors performed chemical tests. 

***Retroville Institution for Research***, September, 2006-2009
* Interned for 3 years and with that time helped with research projects,compiling data, implementing ideas and writing lab reports 
* Assisted with developing Dementia Medicine
* Assisted with developing Cancer Medicine 
  
***Retroville Lab Corp***, March, 2009-Present 
* Worked there for 14 years where I collaboratively worked on solutions for health problems and Held Clinical trials.
* Worked with Professor Finbarr Calamitous 




## Education
---
***Retroville High***
* Graduated with 5.0 GPA
* Valedictorian

***Standford University***
* Completed Bachelor's in Biochemistry
* Valedictorian of my class

***Massachussetts Institute of Technology***
* Ph.D in Medical Science
* Gratuated in the top 2%
* 
  




## Projects
---
***RetroVille Lab Corp***, June, 2013-2023
* Aiding in the research in the genetic modification of embryos

***Retroville Lab Corps***, February, 2017-2020
* Aiding in research for Sickle Cell Anemia





## Skills
---
* Excellent Lab Skills
* Collaborative
* Good at multitasking
* Respectful
* Accountable
* Great Professionalism
* Self-motivated




## Recognition
---
* Increased the facilities I worked at productivity by 50%
***Retroville Institution for Research***
* Credit for developing vaccines for cancer and Dememtia
***Retroville Lab Corps***
* Received credit for developing medicine for Sickle Cell Anemia 





## Associations
---
***Retroville Hospital***, May, 2002-2006

* Volunteered for 4 years aiding nurses with medication and help doctors performed chemical tests. 

***Retroville Institution for Research***, September, 2006-2009
* Interned for 3 years and with that time helped with research projects,compiling data, implementing ideas and writing lab reports 
* Assisted with developing Dementia Medicine
* Assisted with developing Cancer Medicine


### Contact Info
---
* Work: (415) 523-0057
* Cell: (415) 967-5581
* Retroville, Utah 61703
